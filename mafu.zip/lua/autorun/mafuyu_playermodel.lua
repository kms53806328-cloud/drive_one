player_manager.AddValidModel( "mafuyu", "models/nuj02/gura/mafuyu_pm.mdl" )
player_manager.AddValidHands( "mafuyu", "models/nuj02/gura/mafuyu_arms.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel", "mafuyu", "models/nuj02/gura/mafuyu_pm.mdl" )

local Category = "Vrchat"

local NPC = {	Name = "mafuyu Friendly",
				Class = "npc_citizen",
				Model = "models/nuj02/gura/mafuyu_frendly.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Weapons = {"weapon_smg1" },
				Category = Category }

list.Set( "NPC", "mafuyu_frendly", NPC )

local NPC = {	Name = "mafuyu Hostile",
				Class = "npc_combine_s",
				Model = "models/nuj02/gura/mafuyu_enemy.mdl",
				Health = "100",
				Numgrenades = "4",
                Weapons = { "weapon_ar2"},
				Category = Category }
				
list.Set( "NPC", "mafuyu_enemy", NPC )