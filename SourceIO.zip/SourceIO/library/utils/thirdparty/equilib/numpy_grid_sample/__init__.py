#!/usr/bin/env python

from .faster import grid_sample as default

__all__ = [
    "default",
]
