from typing import Type

from SourceIO.library.source2.blocks.base import BaseBlock
from SourceIO.library.source2.blocks.morph_block import MorphBlock
from SourceIO.library.source2.compiled_resource import CompiledResource


class CompiledMorphResource(CompiledResource):
    pass
