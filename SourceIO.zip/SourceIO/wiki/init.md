* [MDL import properties info](MDL_IMPORT.md)
* [BSP import properties info](BSP_IMPORT.md)