from .vr_eyeball import VrEyeball


class Eyeball(VrEyeball):
    SHADER: str = 'eyeball.vfx'