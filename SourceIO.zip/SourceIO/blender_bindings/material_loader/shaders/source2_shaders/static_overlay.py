from .vr_complex import VrComplex


class StaticOverlay(VrComplex):
    SHADER: str = 'static_overlay.vfx'